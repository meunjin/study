package com.cylab.preventfishing;

import android.app.Notification;
import android.content.Intent;
import android.icu.text.SimpleDateFormat;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;


//@RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
public class ShowNotificationListener extends NotificationListenerService {
    MainActivity mainActivity;
    public final static String TAG = "MyNotificationListener";

    @Override
    public void onCreate() {
        super.onCreate();
        Log.i("NotificationListener", "[showChat] onCreate()");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.i("NotificationListener", "[showChat] onStartCommand()");
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.i("NotificationListener", "[showChat] onDestroy()");
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {

        Notification notification = sbn.getNotification();
        Bundle extras = sbn.getNotification().extras;
        String packageName = sbn.getPackageName();
        String title = extras.getString(Notification.EXTRA_TITLE);  //user name
        CharSequence text = extras.getCharSequence(Notification.EXTRA_TEXT);    //chatting text
        CharSequence subText = extras.getCharSequence(Notification.EXTRA_SUB_TEXT); //group name
        //Icon smallIcon = notification.getSmallIcon();
        //Icon largeIcon = notification.getLargeIcon();


        Log.i("NotificationListener", "[showChat] onNotificationPosted() - " + sbn.toString());
        Log.i("NotificationListener", "[showChat] PackageName:" + sbn.getPackageName());    //PackageName:com.kakao.talk
        Log.i("NotificationListener", "[showChat] PostTime:" + sbn.getPostTime());          //PostTime:1722176070363
        Log.i("NotificationListener", "[showChat] id:" + sbn.getId());          //id:2
        Log.i("NotificationListener", "[showChat] title: " + title);          //title:보낸사람
        Log.i("NotificationListener", "[showChat] text:" + text);          //text:내용
        Log.i("NotificationListener", "[showChat] subText:" + subText);          //subtext:그룹명

        //알람 확인
        //Toast.makeText(this,sbn.getPostTime()+" 보낸이:"+title+"\n"+text, Toast.LENGTH_SHORT).show();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String time = sdf.format (sbn.getPostTime());
        String chatting = time+" 보낸이:"+title+"\n"+text;
        ((MainActivity)MainActivity.mContext).createTextView(chatting);


        /* //카톡일 경우만
        if (!TextUtils.isEmpty(packageName) && packageName.equals("com.kakao.talk")){
            //알람 확인
            Toast.makeText(this,"테스트1 확인", Toast.LENGTH_SHORT).show();
        }
        */
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        //알람 미확인
        //Toast.makeText(this,"테스트2 미확인", Toast.LENGTH_SHORT).show();
        Log.i("NotificationListener", "[showChat] onNotificationRemoved() - " + sbn.toString());
    }

}
