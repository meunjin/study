package com.cylab.preventfishing;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.w3c.dom.Text;

import java.util.Set;


public class MainActivity extends AppCompatActivity {
    LinearLayout DylistView; //대화 동적생성 공간
    Integer numButton = 0; // 버튼의 개수
    public static Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        mContext = this;

        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        DylistView = findViewById(R.id.DynamicListView);

        if(!isNotificationPermissionGranted()) {
            startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button button_save = (Button) this.findViewById(R.id.button_save);
        button_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createTextView("테스트");
                Toast.makeText(getApplicationContext(),"테스트", Toast.LENGTH_SHORT).show();

            }
        });


    }

    //권한 확인
    private boolean isNotificationPermissionGranted() {
        Set<String> notiListenerSet = NotificationManagerCompat.getEnabledListenerPackages(this);
        String myPackageName = getPackageName();

        for(String packageName : notiListenerSet) {
            if(packageName == null) {
                continue;
            }
            if(packageName.equals(myPackageName)) {
                return true;
            }
        }

        return false;
    }

    //새로운 텍스트뷰 추가
    public void createTextView(String chatting){
        int seatGaping = 10;
        numButton++; // 버튼 추가할 때마다 버튼의 개수 1씩 증가

        TextView textViewNm = new TextView(this);
        textViewNm.setId(0x8000+numButton);
        textViewNm.setText(chatting+numButton);
        textViewNm.setTextSize(15);
        textViewNm.setTextColor(Color.BLUE);
        textViewNm.setId(0);
        textViewNm.setPadding(8 * seatGaping, 8 * seatGaping, 8 * seatGaping, 8 * seatGaping);
        DylistView.addView(textViewNm, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT));

    }
}
